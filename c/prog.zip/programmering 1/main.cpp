#include <iostream>
#include <cstdlib>
#include "sbib.h"
using namespace std;

int main()
{

	int index;

	cout << "Enter the size of your array:";
	cin >> index;
	
	bool * arr = new bool[index];
    cout << &arr << endl;
    
    randomizeArray(arr, index);
    
    printOutDynArray(arr, index);

    delete arr;

    return 0;
}
